@extends('layouts.admin')

@section('content')
<div class="container mt-4">
    <h2 class="mb-4">➕ Add New Product</h2>

    <form action="{{ route('admin.products.store') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <!-- Name -->
        <div class="mb-3">
            <label for="name" class="form-label">Product Name</label>
            <input type="text" name="name" id="name" 
                   class="form-control @error('name') is-invalid @enderror" 
                   value="{{ old('name') }}" required>
            @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

        <!-- Category -->
        <div class="mb-3">
            <label for="category" class="form-label">Category</label>
            <select name="category" id="category" class="form-control @error('category') is-invalid @enderror" required>
                <option value="">-- Select Category --</option>
                <option value="T-shirts">T-shirts</option>
                <option value="Shirts">Shirts</option>
                <option value="Polo Shirts">Polo Shirts</option>
                <option value="Sweaters">Sweaters</option>
                <option value="Hoodies">Hoodies</option>
                <option value="Jackets">Jackets</option>
                <option value="Joggers">Joggers</option>
                <option value="Shorts">Shorts</option>
                <option value="Jeans">Jeans</option>
                <option value="Trousers">Trousers</option>
                <option value="Underwear">Underwear</option>
                <option value="Head Gear">Head Gear</option>
                <option value="Bags">Bags</option>
                <option value="Accessories">Accessories</option>
                <option value="Footwear">Footwear</option>
                
            </select>
            @error('category')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

        <!-- Description -->
        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea name="description" id="description" rows="4" 
                      class="form-control @error('description') is-invalid @enderror" required>{{ old('description') }}</textarea>
            @error('description')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

        <!-- Stock -->
        <div class="mb-3">
            <label for="stock" class="form-label">Stock Quantity</label>
            <input type="number" name="stock" id="stock" 
                   class="form-control @error('stock') is-invalid @enderror" 
                   value="{{ old('stock') }}" required>
            @error('stock')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

        <!-- Price -->
        <div class="mb-3">
            <label for="price" class="form-label">Price ($)</label>
            <input type="number" step="0.01" name="price" id="price" 
                   class="form-control @error('price') is-invalid @enderror" 
                   value="{{ old('price') }}" required>
            @error('price')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

        <!-- Image -->
        <div class="mb-3">
            <label for="image" class="form-label">Product Image</label>
            <input type="file" name="image" id="image" 
                   class="form-control @error('image') is-invalid @enderror" accept="image/*" required>
            @error('image')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

        <button type="submit" class="btn btn-success">💾 Save Product</button>
        <a href="{{ route('admin.products.index') }}" class="btn btn-secondary">⬅ Back</a>
    </form>
</div>
@endsection
