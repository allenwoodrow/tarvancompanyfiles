@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Manage Users</h1>
    <p>This is where admin can view, edit, and manage users.</p>
</div>
@endsection
