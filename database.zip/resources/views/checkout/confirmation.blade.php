@extends('layouts.app')

@section('content')
<!--breadcrumbs area start-->
<div class="breadcrumbs_area">
    <div class="container">   
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <h3>Order Confirmation</h3>
                    <ul>
                        <li><a href="{{ route('home') }}">Home</a></li>
                        <li>Order Confirmation</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>         
</div>
<!--breadcrumbs area end-->

<!-- Order Confirmation -->
<div class="Checkout_section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="confirmation-card text-center">
                    <div class="confirmation-icon">
                        <i class="fa fa-check-circle" style="font-size: 60px; color: #28a745;"></i>
                    </div>
                    <h2>Thank You For Your Order!</h2>
                    <p class="order-number">Order #: <strong>{{ $order->order_number }}</strong></p>
                    <p>We've sent a confirmation email to <strong>{{ Auth::user()->email }}</strong></p>
                    
                    <div class="order-details mt-4">
                        <h4>Order Details</h4>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($order->items as $item)
                                        <tr>
                                            <td>{{ $item->product->name }}</td>
                                            <td>{{ $item->quantity }}</td>
                                            <td>${{ number_format($item->price, 2) }}</td>
                                            <td>${{ number_format($item->total, 2) }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="3" class="text-end"><strong>Subtotal:</strong></td>
                                        <td>${{ number_format($order->subtotal, 2) }}</td>
                                    </tr>
                                    <tr>
                                        <td colspan="3" class="text-end"><strong>Shipping:</strong></td>
                                        <td>${{ number_format($order->shipping, 2) }}</td>
                                    </tr>
                                    <tr>
                                        <td colspan="3" class="text-end"><strong>Total:</strong></td>
                                        <td>${{ number_format($order->total, 2) }}</td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>

                    <div class="shipping-info mt-4">
                        <div class="row">
                            <div class="col-md-6">
                                <h5>Shipping Address</h5>
                                <p>
                                    @if(!empty($order->shipping_address))
                                        {{ $order->shipping_address }}
                                    @else
                                        Shipping address not available.
                                    @endif
                                </p>
                            </div>
                            <div class="col-md-6">
                                <h5>Billing Address</h5>
                                <p>
                                    @if(!empty($order->billing_address))
                                        {{ $order->billing_address }}
                                    @else
                                        Billing address not available.
                                    @endif
                                </p>
                                <br>
                                <h5>Payment Method</h5>
                                <p>{{ $order->payment_method }}</p>
                                <p><strong>Status:</strong> {{ ucfirst($order->status) }}</p>
                            </div>
                        </div>
                    </div>

                    <div class="action-buttons mt-4">
                        <a href="{{ route('home') }}" class="btn btn-primary">Continue Shopping</a>
                        <a href="{{ route('profile.orders') }}" class="btn btn-outline-secondary">View Order History</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection