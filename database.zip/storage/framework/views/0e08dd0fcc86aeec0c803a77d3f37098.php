

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="mb-4">Orders</h2>
    <a href="<?php echo e(route('admin.orders.create')); ?>" class="btn btn-primary mb-3">➕ New Order</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-striped align-middle">
        <thead>
            <tr>
                <th>#</th>
                <th>User</th>
                <th>Product</th>
                <th>Quantity</th>
                <th>Total ($)</th>
                <th>Status</th>
                <th>Payment</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($order->id); ?></td>
                <td><?php echo e($order->user ? $order->user->name : 'N/A'); ?></td>
                <td><?php echo e($order->product ? $order->product->name : 'N/A'); ?></td>
                <td><?php echo e($order->quantity); ?></td>
                <td>$<?php echo e(number_format($order->total, 2)); ?></td>
                <td><?php echo e(ucfirst($order->status)); ?></td>
                <td>
                    <?php if($order->payment): ?>
                        <span class="badge bg-success">Paid</span>
                    <?php else: ?>
                        <span class="badge bg-warning">Unpaid</span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(route('admin.orders.edit', $order)); ?>" class="btn btn-sm btn-warning">✏ Edit</a>
                    <form action="<?php echo e(route('admin.orders.destroy', $order)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger" onclick="return confirm('Delete order?')">🗑 Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="8" class="text-center">No orders found</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Cipher\Documents\Shop\htmldemo.net\braga\fashion-store\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>