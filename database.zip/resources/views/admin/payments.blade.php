@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Manage Payments</h1>
    <p>This is where admin can manage and add payment methods.</p>
</div>
@endsection
