

<?php $__env->startSection('content'); ?>
<!--breadcrumbs area start-->
<div class="breadcrumbs_area">
    <div class="container">   
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <h3>Shop</h3>
                    <ul>
                        <li><a href="<?php echo e(route('home')); ?>">home</a></li>
                        <li>shop</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>         
</div>
<!--breadcrumbs area end-->

<!--shop  area start-->
<div class="shop_area shop_reverse mb-80">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-12">
               <!--sidebar widget start-->
                <aside class="sidebar_widget">
                    <div class="widget_inner">
                        <!-- Search Form -->
                        <div class="widget_list widget_search">
                            <h3>Search Products</h3>
                            <form action="<?php echo e(route('shop')); ?>" method="GET">
                                <input type="text" name="search" placeholder="Search products..." value="<?php echo e(request('search')); ?>">
                                <button type="submit"><i class="fa fa-search"></i></button>
                            </form>
                        </div>

                        <!-- Price Filter -->
                        <div class="widget_list widget_filter">
                            <h3>Filter by price</h3>
                            <form action="<?php echo e(route('shop')); ?>" method="GET" id="price-filter-form">
                                <div id="slider-range"></div>   
                                <button type="submit">Filter</button>
                                <input type="text" name="price_range" id="amount" readonly />   
                                <input type="hidden" name="min_price" id="min_price" value="<?php echo e(request('min_price')); ?>">
                                <input type="hidden" name="max_price" id="max_price" value="<?php echo e(request('max_price')); ?>">
                            </form> 
                        </div>

                        <!-- Color Filter -->
                        <div class="widget_list widget_color">
                            <h3>Select By Color</h3>
                            <ul>
                                <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('shop', ['color' => $color] + request()->except('color'))); ?>" 
                                       class="<?php echo e(request('color') == $color ? 'active' : ''); ?>">
                                        <?php echo e(ucfirst($color)); ?>  
                                        <span>(<?php echo e($colorCounts[$color] ?? 0); ?>)</span>
                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>

                        <!-- Size Filter -->
                        <div class="widget_list widget_color">
                            <h3>Select By Size</h3>
                            <ul>
                                <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('shop', ['size' => $size] + request()->except('size'))); ?>" 
                                       class="<?php echo e(request('size') == $size ? 'active' : ''); ?>">
                                        <?php echo e($size); ?>  
                                        <span>(<?php echo e($sizeCounts[$size] ?? 0); ?>)</span>
                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>

                        <!-- Clear Filters -->
                        <?php if(request()->anyFilled(['search', 'min_price', 'max_price', 'color', 'size', 'sort'])): ?>
                        <div class="widget_list">
                            <a href="<?php echo e(route('shop')); ?>" class="btn btn-secondary btn-block">Clear All Filters</a>
                        </div>
                        <?php endif; ?>
                    </div>
                </aside>
                <!--sidebar widget end-->
            </div>
            <div class="col-lg-9 col-md-12">
                <!--shop wrapper start-->
                
                <!--shop toolbar start-->
                <div class="shop_toolbar_wrapper">
                    <div class="shop_toolbar_btn">
                        <button data-role="grid_4" type="button" class="active btn-grid-4" data-bs-toggle="tooltip" title="4"></button>
                        <button data-role="grid_3" type="button" class="btn-grid-3" data-bs-toggle="tooltip" title="3"></button>
                        <button data-role="grid_list" type="button" class="btn-list" data-bs-toggle="tooltip" title="List"></button>
                    </div>
                    <div class="niceselect_option">
                        <form class="select_option" action="<?php echo e(route('shop')); ?>" method="GET" id="sort-form">
                            <?php $__currentLoopData = request()->except('sort'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <select name="sort" id="short" onchange="this.form.submit()">
                                <option value="newest" <?php echo e(request('sort') == 'newest' ? 'selected' : ''); ?>>Sort by newness</option>
                                <option value="price_asc" <?php echo e(request('sort') == 'price_asc' ? 'selected' : ''); ?>>Sort by price: low to high</option>
                                <option value="price_desc" <?php echo e(request('sort') == 'price_desc' ? 'selected' : ''); ?>>Sort by price: high to low</option>
                                <option value="name_asc" <?php echo e(request('sort') == 'name_asc' ? 'selected' : ''); ?>>Product Name: A-Z</option>
                                <option value="name_desc" <?php echo e(request('sort') == 'name_desc' ? 'selected' : ''); ?>>Product Name: Z-A</option>
                            </select>
                        </form>
                    </div>
                    <div class="page_amount">
                        <p>Showing <?php echo e($products->firstItem()); ?>–<?php echo e($products->lastItem()); ?> of <?php echo e($products->total()); ?> results</p>
                    </div>
                </div>
                 <!--shop toolbar end-->
                 
                 <div class="row shop_wrapper grid_4">
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-3 col-md-4 col-sm-6 col-12">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="<?php echo e(route('product.show', $product->id)); ?>">
                                    <img src="<?php echo e($product->image ? asset($product->image) : asset('assets/img/product/default.jpg')); ?>" alt="<?php echo e($product->name); ?>">
                                </a>
                                <?php if($product->old_price && $product->old_price > $product->price): ?>
                                <div class="label_product">
                                    <span class="label_sale">Sale</span>
                                </div>
                                <?php endif; ?>
                                <div class="action_links">
                                    <ul>
                                        <li class="quick_button">
                                            <a href="#" class="quick-view-btn"
                                               data-id="<?php echo e($product->id); ?>"
                                               data-name="<?php echo e($product->name); ?>"
                                               data-price="<?php echo e(number_format($product->price, 2)); ?>"
                                               data-oldprice="<?php echo e($product->old_price ? number_format($product->old_price, 2) : ''); ?>"
                                               data-description="<?php echo e($product->description); ?>"
                                               data-images='<?php echo json_encode([$product->image ? asset($product->image) : asset('assets/img/product/default.jpg')], 15, 512) ?>'
                                               data-bs-toggle="modal"
                                               data-bs-target="#modal_box">
                                                <span class="pe-7s-search"></span>
                                            </a>
                                        </li>
                                        <li class="wishlist">
                                            <a href="<?php echo e(route('wishlist.add', $product->id)); ?>">
                                                <span class="pe-7s-like"></span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content grid_content">
                                <div class="product_content_inner">
                                    <h4 class="product_name">
                                        <a href="<?php echo e(route('product.show', $product->id)); ?>"><?php echo e($product->name); ?></a>
                                    </h4>
                                    <div class="price_box"> 
                                        <?php if($product->old_price && $product->old_price > $product->price): ?>
                                        <span class="old_price">$<?php echo e(number_format($product->old_price, 2)); ?></span>
                                        <?php endif; ?>
                                        <span class="current_price">$<?php echo e(number_format($product->price, 2)); ?></span>
                                    </div>
                                </div>
                                <div class="add_to_cart">
                                    <a href="javascript:void(0)" class="add-to-cart-btn" data-id="<?php echo e($product->id); ?>">Add to cart</a>
                                </div>
                            </div>
                            <div class="product_content list_content" style="display: none;">
                                <h4 class="product_name">
                                    <a href="<?php echo e(route('product.show', $product->id)); ?>"><?php echo e($product->name); ?></a>
                                </h4>
                                <div class="price_box"> 
                                    <?php if($product->old_price && $product->old_price > $product->price): ?>
                                    <span class="old_price">$<?php echo e(number_format($product->old_price, 2)); ?></span>
                                    <?php endif; ?>
                                    <span class="current_price">$<?php echo e(number_format($product->price, 2)); ?></span>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <?php for($i = 1; $i <= 5; $i++): ?>
                                        <li>
                                            <a href="#">
                                                <i class="ion-android-star<?php echo e($i <= ($product->rating ?? 0) ? '' : '-outline'); ?>"></i>
                                            </a>
                                        </li>
                                        <?php endfor; ?>
                                    </ul>
                                </div>
                                <div class="product_desc">
                                    <p><?php echo e(Str::limit($product->description, 150)); ?></p>
                                </div>
                                <div class="add_to_cart shop_list_cart">
                                    <a href="javascript:void(0)" class="add-to-cart-btn" data-id="<?php echo e($product->id); ?>">Add to cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12">
                        <div class="alert alert-info text-center">
                            <h4>No products found</h4>
                            <p>Try adjusting your search or filter criteria</p>
                            <a href="<?php echo e(route('shop')); ?>" class="btn btn-primary">Clear Filters</a>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div class="shop_toolbar t_bottom">
                    <div class="pagination">
                        <?php echo e($products->appends(request()->query())->links('vendor.pagination.custom')); ?>

                    </div>
                </div>
                <!--shop toolbar end-->
                <!--shop wrapper end-->
            </div>
        </div>
    </div>
</div>
<!--shop  area end-->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener("DOMContentLoaded", function() {
    // Grid/List view toggle
    const gridButtons = document.querySelectorAll('.shop_toolbar_btn button');
    const shopWrapper = document.querySelector('.shop_wrapper');
    
    gridButtons.forEach(button => {
        button.addEventListener('click', function() {
            const role = this.getAttribute('data-role');
            
            // Remove active class from all buttons
            gridButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            this.classList.add('active');
            
            // Remove all grid classes
            shopWrapper.classList.remove('grid_4', 'grid_3', 'list');
            // Add the selected grid class
            shopWrapper.classList.add(role);
            
            // Show/hide grid/list content
            if (role === 'grid_list') {
                document.querySelectorAll('.grid_content').forEach(el => el.style.display = 'none');
                document.querySelectorAll('.list_content').forEach(el => el.style.display = 'block');
            } else {
                document.querySelectorAll('.grid_content').forEach(el => el.style.display = 'block');
                document.querySelectorAll('.list_content').forEach(el => el.style.display = 'none');
            }
        });
    });

    // Price range slider
    const minPrice = <?php echo e(request('min_price', 0)); ?>;
    const maxPrice = <?php echo e(request('max_price', 1000)); ?>;
    const maxProductPrice = <?php echo e($maxPrice ?? 1000); ?>;
    
    $("#slider-range").slider({
        range: true,
        min: 0,
        max: maxProductPrice,
        values: [minPrice, maxPrice],
        slide: function(event, ui) {
            $("#amount").val("$" + ui.values[0] + " - $" + ui.values[1]);
            $("#min_price").val(ui.values[0]);
            $("#max_price").val(ui.values[1]);
        }
    });
    
    $("#amount").val("$" + $("#slider-range").slider("values", 0) + " - $" + $("#slider-range").slider("values", 1));

    // Add to cart functionality
    document.querySelectorAll('.add-to-cart-btn').forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.dataset.id;
            addToCart(productId);
        });
    });

    function addToCart(productId) {
        const formData = new FormData();
        formData.append('_token', '<?php echo e(csrf_token()); ?>');
        formData.append('product_id', productId);
        formData.append('quantity', 1);

        fetch('<?php echo e(route("cart.add")); ?>', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update cart count
                document.querySelectorAll('.item_count').forEach(el => {
                    el.textContent = data.cart_count;
                });
                
                // Show success message
                showNotification('Product added to cart!', 'success');
            } else {
                showNotification('Error adding product to cart', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showNotification('Error adding product to cart', 'error');
        });
    }

    function showNotification(message, type) {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} fixed-top mx-auto mt-3`;
        notification.style.cssText = 'max-width: 300px; z-index: 9999; left: 50%; transform: translateX(-50%); text-align: center; padding: 10px;';
        notification.textContent = message;
        
        // Add to body
        document.body.appendChild(notification);
        
        // Remove after 3 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }

    // Quick view modal functionality
    document.querySelectorAll('.quick-view-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            // Fill modal with product data
            const modal = document.getElementById('modal_box');
            modal.querySelector('.modal_title h2').textContent = this.dataset.name;
            modal.querySelector('.new_price').textContent = '$' + this.dataset.price;
            
            const oldPrice = modal.querySelector('.old_price');
            if (this.dataset.oldprice) {
                oldPrice.textContent = '$' + this.dataset.oldprice;
                oldPrice.style.display = 'inline';
            } else {
                oldPrice.style.display = 'none';
            }
            
            modal.querySelector('.modal_description p').textContent = this.dataset.description;
            
            // Parse and set images
            let images = [];
            try {
                images = JSON.parse(this.dataset.images.replace(/&quot;/g, '"'));
            } catch (e) {
                images = [this.dataset.images];
            }
            
            // Update modal images
            const tabContent = modal.querySelector('.product-details-large');
            const thumbnails = modal.querySelector('.product_navactive');
            
            tabContent.innerHTML = '';
            thumbnails.innerHTML = '';
            
            images.forEach((img, index) => {
                // Main image tabs
                tabContent.innerHTML += `
                    <div class="tab-pane fade ${index === 0 ? 'show active' : ''}" id="tab${index + 1}" role="tabpanel">
                        <div class="modal_tab_img">
                            <img src="${img}" alt="${this.dataset.name}">    
                        </div>
                    </div>
                `;
                
                // Thumbnails
                thumbnails.innerHTML += `
                    <li>
                        <a class="nav-link ${index === 0 ? 'active' : ''}" data-bs-toggle="tab" href="#tab${index + 1}" role="tab">
                            <img src="${img}" alt="${this.dataset.name}">
                        </a>
                    </li>
                `;
            });
            
            // Update add to cart form
            const addToCartForm = modal.querySelector('.modal_add_to_cart form');
            addToCartForm.querySelector('input[type="number"]').value = 1;
            addToCartForm.setAttribute('data-product-id', this.dataset.id);
        });
    });

    // Modal add to cart
    document.querySelector('#modal_box .modal_add_to_cart form')?.addEventListener('submit', function(e) {
        e.preventDefault();
        const productId = this.getAttribute('data-product-id');
        const quantity = this.querySelector('input[type="number"]').value;
        
        addToCart(productId, quantity);
        
        // Close modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('modal_box'));
        modal.hide();
    });
});
</script>

<style>
.shop_wrapper.grid_4 .col-lg-3 {
    flex: 0 0 25%;
    max-width: 25%;
}
.shop_wrapper.grid_3 .col-lg-3 {
    flex: 0 0 33.333%;
    max-width: 33.333%;
}
.shop_wrapper.list .single_product {
    width: 100%;
    display: flex;
}
.shop_wrapper.list .product_thumb {
    width: 30%;
    margin-right: 20px;
}
.shop_wrapper.list .product_content {
    width: 70%;
}

/* Active filter styles */
.widget_list a.active {
    color: #007bff;
    font-weight: bold;
}

/* Pagination styles */
.pagination {
    display: flex;
    justify-content: center;
}
.pagination ul {
    display: flex;
    list-style: none;
    padding: 0;
    margin: 0;
}
.pagination li {
    margin: 0 5px;
}
.pagination li a,
.pagination li.current {
    display: block;
    padding: 8px 15px;
    border: 1px solid #ddd;
    border-radius: 3px;
    text-decoration: none;
    color: #333;
}
.pagination li.current {
    background: #007bff;
    color: white;
    border-color: #007bff;
}
.pagination li a:hover {
    background: #f8f9fa;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Cipher\Documents\Shop\htmldemo.net\braga\fashion-store\resources\views/shop.blade.php ENDPATH**/ ?>