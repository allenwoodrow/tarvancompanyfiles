<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Cart extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'session_id',
        'subtotal',
        'shipping',
        'total'
    ];

    public function items()
    {
        return $this->hasMany(CartItem::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get or create cart for the current user/session
     */
    public static function getCart($request)
    {
        // If user is authenticated, try to get their cart
        if (Auth::check()) {
            $cart = self::firstOrCreate(
                ['user_id' => Auth::id()],
                [
                    'subtotal' => 0,
                    'shipping' => 0,
                    'total' => 0
                ]
            );
        } else {
            // For guests, use session ID
            $sessionId = $request->session()->getId();
            $cart = self::firstOrCreate(
                ['session_id' => $sessionId],
                [
                    'subtotal' => 0,
                    'shipping' => 0,
                    'total' => 0
                ]
            );
        }

        return $cart;
    }

    /**
     * Update cart totals based on items
     */
    public function updateTotals()
    {
        $subtotal = $this->items->sum(function ($item) {
            return $item->price * $item->quantity;
        });

        // Calculate shipping (example: $5 flat rate)
        $shipping = 5.00;
        
        $total = $subtotal + $shipping;

        $this->update([
            'subtotal' => $subtotal,
            'shipping' => $shipping,
            'total' => $total
        ]);

        return $this;
    }

    /**
     * Clear all items from cart
     */
    public function clear()
    {
        $this->items()->delete();
        $this->updateTotals();
        return $this;
    }
}