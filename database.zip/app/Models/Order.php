<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Order extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'user_id',
        'order_number',
        'status',
        'subtotal',
        'shipping',
        'total',
        'shipping_address',
        'billing_address',
        'payment_method',
        'notes'
    ];

    protected $casts = [
        'subtotal' => 'decimal:2',
        'shipping' => 'decimal:2',
        'total' => 'decimal:2',
    ];

        // Accessor for shipping address
    // In your Order.php model
    public function getShippingAddressAttribute($value)
    {
        // Try to decode as JSON, if it fails, return as string
        $decoded = json_decode($value, true);
        return json_last_error() === JSON_ERROR_NONE ? $decoded : $value;
    }

    public function getBillingAddressAttribute($value)
    {
        // Try to decode as JSON, if it fails, return as string
        $decoded = json_decode($value, true);
        return json_last_error() === JSON_ERROR_NONE ? $decoded : $value;
    }

    // Relationship with user
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // Relationship with order items
    public function items()
    {
        return $this->hasMany(OrderItem::class);
    }

    // Relationship with payment
    public function payment()
    {
        return $this->hasOne(Payment::class);
    }

    // Calculate total items in order
    public function getTotalItemsAttribute()
    {
        return $this->items->sum('quantity');
    }

    // Accessor for formatted order number
    public function getFormattedOrderNumberAttribute()
    {
        return 'ORD-' . strtoupper($this->order_number);
    }

    // Relationship with product (if you need it)
    public function product()
    {
        return $this->belongsTo(Product::class);
    }

}