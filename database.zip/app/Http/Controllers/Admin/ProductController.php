<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::latest()->get();
        return view('admin.products.index', compact('products'));
    }

    public function create()
    {
        return view('admin.products.create');
    }

public function store(Request $request)
{
    $request->validate([
        'name' => 'required|string',
        'price' => 'required|numeric',
        'stock' => 'required|integer',
        'description' => 'nullable|string',
        'category' => 'required|string',
        'image' => 'nullable|image|mimes:jpg,jpeg,png,gif|max:2048',
    ]);

    $data = $request->only(['name', 'price', 'stock', 'description', 'category']);

    // Handle image upload
    if ($request->hasFile('image')) {
        $file = $request->file('image');
        $filename = time() . '_' . $file->getClientOriginalName();
        $file->move(public_path('products'), $filename);
        $data['image'] = 'products/' . $filename;
    }

    Product::create($data);

    return redirect()->route('admin.products.index')->with('success', 'Product added successfully!');
}

    public function edit(Product $product)
    {
        return view('admin.products.edit', compact('product'));
    }

    

public function update(Request $request, Product $product)
{
    $request->validate([
        'name' => 'required|string',
        'price' => 'required|numeric',
        'stock' => 'required|integer',
        'description' => 'nullable|string',
        'category' => 'required|string',
        'image' => 'nullable|image|mimes:jpg,jpeg,png,gif|max:2048',
    ]);

    $data = $request->only(['name', 'price', 'stock', 'description', 'category']);

    // Handle new image if uploaded
    if ($request->hasFile('image')) {
        $file = $request->file('image');
        $filename = time() . '_' . $file->getClientOriginalName();
        $file->move(public_path('products'), $filename);
        $data['image'] = 'products/' . $filename;
    }

    $product->update($data);

    return redirect()->route('admin.products.index')->with('success', 'Product updated successfully!');
}


    public function destroy(Product $product)
    {
        // delete image from /public/products
        if ($product->image && file_exists(public_path($product->image))) {
            unlink(public_path($product->image));
        }

        $product->delete();

        return redirect()->route('admin.products.index')
            ->with('success', '🗑 Product deleted successfully!');
    }
}
