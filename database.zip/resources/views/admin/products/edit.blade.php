@extends('layouts.admin')

@section('content')
<div class="container mt-4">
    <h2 class="mb-4">✏ Edit Product</h2>

    <form action="{{ route('admin.products.update', $product->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <!-- Name -->
        <div class="mb-3">
            <label for="name" class="form-label">Product Name</label>
            <input type="text" name="name" id="name" 
                   class="form-control @error('name') is-invalid @enderror" 
                   value="{{ old('name', $product->name) }}" required>
            @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

        <!-- Category -->
        <div class="mb-3">
            <label for="category" class="form-label">Category</label>
            @php
                $categories = ['T-shirts','Shirts','Polo Shirts','Sweaters','Hoodies','Jackets','Joggers','Shorts','Jeans','Trousers', 'Underwear', 'Head Gear'];
            @endphp
            <select name="category" id="category" class="form-control @error('category') is-invalid @enderror" required>
                @foreach($categories as $cat)
                    <option value="{{ $cat }}" {{ old('category', $product->category) === $cat ? 'selected' : '' }}>
                        {{ $cat }}
                    </option>
                @endforeach
            </select>
            @error('category')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

        <!-- Description -->
        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea name="description" id="description" rows="4" 
                      class="form-control @error('description') is-invalid @enderror" required>{{ old('description', $product->description) }}</textarea>
            @error('description')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

        <!-- Stock -->
        <div class="mb-3">
            <label for="stock" class="form-label">Stock Quantity</label>
            <input type="number" name="stock" id="stock" 
                   class="form-control @error('stock') is-invalid @enderror" 
                   value="{{ old('stock', $product->stock) }}" required>
            @error('stock')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

        <!-- Price -->
        <div class="mb-3">
            <label for="price" class="form-label">Price ($)</label>
            <input type="number" step="0.01" name="price" id="price" 
                   class="form-control @error('price') is-invalid @enderror" 
                   value="{{ old('price', $product->price) }}" required>
            @error('price')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

        <!-- Image -->
        <div class="mb-3">
            <label for="image" class="form-label">Product Image</label><br>
            @if($product->image)
                <img src="{{ asset('/' . $product->image) }}" alt="Current Image" class="img-thumbnail mb-2" width="150">
            @endif
            <input type="file" name="image" id="image" 
                   class="form-control @error('image') is-invalid @enderror" accept="image/*">
            @error('image')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

        <button type="submit" class="btn btn-primary">💾 Update Product</button>
        <a href="{{ route('admin.products.index') }}" class="btn btn-secondary">⬅ Back</a>
    </form>
</div>
@endsection
