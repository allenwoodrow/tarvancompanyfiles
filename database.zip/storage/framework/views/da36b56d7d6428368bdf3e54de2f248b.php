

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="mb-4">Products</h2>
    <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary mb-3">➕ Add Product</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-striped align-middle">
        <thead>
            <tr>
                <th>#</th>
                <th>Image</th>
                <th>Name</th>
                <th>Category</th>
                <th>Stock</th>
                <th>Price</th>
                <th>Description</th>
                <th style="width:150px;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($product->id); ?></td>
                <td>
                    <?php if($product->image): ?>
                        <img src="<?php echo e(asset($product->image)); ?>" 
                             alt="<?php echo e($product->name); ?>" 
                             width="60" height="60" 
                             class="rounded border">
                    <?php else: ?>
                        <span class="text-muted">No image</span>
                    <?php endif; ?>
                </td>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->category); ?></td>
                <td><?php echo e($product->stock); ?></td>
                <td>$<?php echo e(number_format($product->price, 2)); ?></td>
                <td><?php echo e(Str::limit($product->description, 50)); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.products.edit', $product)); ?>" 
                       class="btn btn-sm btn-warning">✏ Edit</a>
                    <form action="<?php echo e(route('admin.products.destroy', $product)); ?>" 
                          method="POST" 
                          class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger" 
                                onclick="return confirm('Delete this product?')">🗑 Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="8" class="text-center">No products found</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Cipher\Documents\Shop\htmldemo.net\braga\fashion-store\resources\views/admin/products/index.blade.php ENDPATH**/ ?>