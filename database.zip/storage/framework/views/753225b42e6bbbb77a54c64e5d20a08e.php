

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Payment Methods</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('admin.payment-methods.create')); ?>" class="btn btn-primary mb-3">Add New Payment Method</a>

    <table class="table table-bordered table-hover">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Method Name</th>
                <th>Account Name / Email</th>
                <th>Account Email</th>
                <th>Account Number</th>
                <th>Bank / Platform</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($method->id); ?></td>
                <td><?php echo e($method->name); ?></td>
                <td><?php echo e($method->account_name ?? '-'); ?></td>
                <td><?php echo e($method->account_email ?? '-'); ?></td>
                <td><?php echo e($method->account_number ?? '-'); ?></td>
                <td><?php echo e($method->bank_name ?? '-'); ?></td>
                <td>
                    <?php if($method->status): ?>
                        <span class="badge bg-success">Active</span>
                    <?php else: ?>
                        <span class="badge bg-secondary">Inactive</span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(route('admin.payment-methods.edit', $method->id)); ?>" class="btn btn-sm btn-warning">Edit</a>

                    <form action="<?php echo e(route('admin.payment-methods.destroy', $method->id)); ?>" method="POST" class="d-inline-block" onsubmit="return confirm('Are you sure you want to delete this method?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="8" class="text-center">No payment methods found.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Cipher\Documents\Shop\htmldemo.net\braga\fashion-store\resources\views/admin/payment-methods/index.blade.php ENDPATH**/ ?>