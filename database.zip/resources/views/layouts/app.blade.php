<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- CSS -->
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/owl.carousel.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/slick.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/magnific-popup.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/font.awesome.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/ionicons.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/pe-icon-7-stroke.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/animate.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/jquery-ui.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/plugins.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">

    <!-- Scripts -->
    <script src="{{ asset('assets/js/vendor/modernizr-3.7.1.min.js') }}"></script>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="font-sans antialiased">
<div class="min-h-screen bg-gray-100">

    <!-- Global Header -->
    @include('layouts.navigation')

    <!-- Page Content -->
    <main>
        @yield('content')
    </main>
</div>

<!-- Global Footer -->
<footer class="footer_widgets">
    <div class="container">
        <div class="footer_top">
            <div class="row">
                <div class="col-12">
                    <div class="newsletter_area">
                        <div class="section_title"><h2>Keep Connected</h2></div>
                        <div class="newsletter_desc"><p>Get updates by subscribing to our weekly newsletter</p></div>
                        <div class="subscribe_form">
                            <form id="mc-form" class="mc-form footer-newsletter">
                                <input id="mc-email" type="email" autocomplete="off" placeholder="Your email address"/>
                                <button id="mc-submit">Subscribe</button>
                            </form>
                            <div class="mailchimp-alerts text-centre">
                                <div class="mailchimp-submitting"></div>
                                <div class="mailchimp-success"></div>
                                <div class="mailchimp-error"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer_middle">
            <div class="row">
                <div class="col-12">
                    <div class="footer_social">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-youtube-play"></i></a></li>
                            <li><a href="#"><i class="fa fa-google"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer_bottom">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-7">
                    <div class="footer_bottom_left">
                        <div class="footer_logo">
                            <a href="{{ route('home') }}"><img src="{{ asset('assets/img/logo/logo2.png') }}" alt="SOD Life+Style"></a>
                        </div>
                        <div class="copyright_area">
                            <p>Copyright © {{ date('Y') }}
                                <a href="{{ route('home') }}">SOD Life+Style</a>.
                                All rights reserved.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-5">
                    <div class="footer_paypal text-right">
                        <a href="#"><img src="{{ asset('assets/img/icon/payment.png') }}" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- JS -->
<script src="{{ asset('assets/js/vendor/jquery-3.4.1.min.js') }}"></script>
<script src="{{ asset('assets/js/popper.js') }}"></script>
<script src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('assets/js/owl.carousel.min.js') }}"></script>
<script src="{{ asset('assets/js/slick.min.js') }}"></script>
<script src="{{ asset('assets/js/jquery.magnific-popup.min.js') }}"></script>
<script src="{{ asset('assets/js/jquery.countdown.js') }}"></script>
<script src="{{ asset('assets/js/jquery.ui.js') }}"></script>
<script src="{{ asset('assets/js/jquery.elevatezoom.js') }}"></script>
<script src="{{ asset('assets/js/isotope.pkgd.min.js') }}"></script>
<script src="{{ asset('assets/js/plugins.js') }}"></script>
<script src="{{ asset('assets/js/main.js') }}"></script>

<!-- jQuery UI -->
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

@yield('scripts')

<script>
// Global cart manager
window.CartManager = {
    CSRF_TOKEN: '{{ csrf_token() }}',
    
    // Update mini cart from any page
    updateMiniCart: function(data) {
        try {
            // Update cart count
            if (data.cart_count !== undefined) {
                document.querySelectorAll('.item_count').forEach(el => {
                    el.textContent = data.cart_count;
                });
            }
            
            // Update mini cart contents
            const miniCart = document.querySelector('.mini_cart');
            if (!miniCart) return;
            
            const cartGallery = miniCart.querySelector('.cart_gallery');
            if (cartGallery && data.cart) {
                let html = `
                    <div class="cart_close">
                        <div class="cart_text"><h3>Cart</h3></div>
                        <div class="mini_cart_close"><a href="javascript:void(0)"><i class="ion-android-close"></i></a></div>
                    </div>
                `;
                
                if (data.cart.items && Object.keys(data.cart.items).length > 0) {
                    Object.entries(data.cart.items).forEach(([id, item]) => {
                        html += `
                            <div class="cart_item" data-id="${id}">
                                <div class="cart_img">
                                    <a href="#"><img src="${item.image}" alt="${item.name}" width="50"></a>
                                </div>
                                <div class="cart_info">
                                    <a href="#">${item.name}</a>
                                    <p>${item.quantity} x <span>$${parseFloat(item.price).toFixed(2)}</span></p>
                                </div>
                                <div class="cart_remove">
                                    <a href="javascript:void(0)" class="mini-cart-remove" data-id="${id}">
                                        <i class="ion-ios-close-outline"></i>
                                    </a>
                                </div>
                            </div>
                        `;
                    });
                } else {
                    html += '<p class="text-center">Your cart is empty</p>';
                }
                
                cartGallery.innerHTML = html;
                
                // Update mini cart totals
                if (data.cart.subtotal !== undefined) {
                    const subtotalEl = miniCart.querySelector('.subtotal-price');
                    if (subtotalEl) subtotalEl.textContent = '$' + parseFloat(data.cart.subtotal).toFixed(2);
                }
                
                if (data.cart.total !== undefined) {
                    const totalEl = miniCart.querySelector('.total-price');
                    if (totalEl) totalEl.textContent = '$' + parseFloat(data.cart.total).toFixed(2);
                }
                
                // Reattach event listeners
                this.attachMiniCartEvents();
            }
        } catch (error) {
            console.error('Error updating mini cart:', error);
        }
    },
    
    // Attach event listeners to mini cart
    attachMiniCartEvents: function() {
        try {
            document.querySelectorAll('.mini-cart-remove').forEach(button => {
                // Remove any existing listeners to prevent duplicates
                button.replaceWith(button.cloneNode(true));
            });
            
            // Reattach event listeners
            document.querySelectorAll('.mini-cart-remove').forEach(button => {
                button.addEventListener('click', (e) => {
                    e.preventDefault();
                    const id = button.dataset.id;
                    
                    fetch(`/cart/remove/${id}`, {
                        method: 'DELETE',
                        headers: {
                            'X-CSRF-TOKEN': this.CSRF_TOKEN,
                            'X-Requested-With': 'XMLHttpRequest',
                            'Accept': 'application/json'
                        }
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            this.updateMiniCart(data);
                            // Dispatch custom event to notify other components
                            window.dispatchEvent(new CustomEvent('cart:updated', { detail: data }));
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
                });
            });
        } catch (error) {
            console.error('Error attaching mini cart events:', error);
        }
    },
    
    // Show notification
    showNotification: function(message, type) {
        // Remove any existing notifications
        document.querySelectorAll('.cart-notification').forEach(el => el.remove());
        
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `cart-notification alert alert-${type === 'success' ? 'success' : 'danger'} fixed-top mx-auto mt-3`;
        notification.style.cssText = 'max-width: 300px; z-index: 9999; left: 50%; transform: translateX(-50%); text-align: center; padding: 10px;';
        notification.textContent = message;
        
        // Add to body
        document.body.appendChild(notification);
        
        // Remove after 3 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }
};

// Initialize when DOM is loaded
document.addEventListener("DOMContentLoaded", function() {
    // Load initial cart data
    CartManager.refreshCart();
    
    // Listen for cart update events
    window.addEventListener('cart:updated', function(e) {
        CartManager.updateMiniCart(e.detail);
    });
    
    console.log("CartManager initialized successfully");
});

// Add refreshCart method to CartManager
CartManager.refreshCart = function() {
    fetch("{{ route('cart.data') }}", { 
        headers: { 
            "X-Requested-With": "XMLHttpRequest",
            "Accept": "application/json"
        } 
    })
    .then(response => {
        if (!response.ok) {
            // If not authenticated, show empty cart
            return {
                success: true,
                cart: {
                    items: {},
                    subtotal: 0,
                    total: 0,
                    count: 0
                },
                cart_count: 0
            };
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            this.updateMiniCart(data);
        } else {
            console.error('Error refreshing cart:', data.message);
            // Show empty cart on error
            this.updateMiniCart({
                cart: {
                    items: {},
                    subtotal: 0,
                    total: 0,
                    count: 0
                },
                cart_count: 0
            });
        }
    })
    .catch(error => {
        console.error('Error refreshing cart:', error);
        // Show empty cart on error
        this.updateMiniCart({
            cart: {
                items: {},
                subtotal: 0,
                total: 0,
                count: 0
            },
            cart_count: 0
        });
    });
};

// Global add to cart handler
document.addEventListener('click', function(e) {
    if (e.target.closest('.add-to-cart-btn')) {
        const button = e.target.closest('.add-to-cart-btn');
        const productId = button.dataset.id;
        
        const formData = new FormData();
        formData.append('_token', CartManager.CSRF_TOKEN);
        formData.append('product_id', productId);
        formData.append('quantity', 1);
        
        fetch('{{ route("cart.add") }}', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => {
            if (response.status === 401) {
                // User is not authenticated, redirect to login
                return response.json().then(data => {
                    if (data.redirect) {
                        window.location.href = data.redirect;
                    } else {
                        window.location.href = '{{ route("login") }}';
                    }
                    return { success: false };
                });
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                CartManager.updateMiniCart(data);
                CartManager.showNotification('Product added to cart!', 'success');
                // Dispatch event for other components
                window.dispatchEvent(new CustomEvent('cart:updated', { detail: data }));
                
                // Close modal if it's open
                const modal = document.getElementById('modal_box');
                if (modal) {
                    const bootstrapModal = bootstrap.Modal.getInstance(modal);
                    if (bootstrapModal) {
                        bootstrapModal.hide();
                    }
                }
            } else if (data.redirect) {
                // Redirect to login page
                window.location.href = data.redirect;
            } else {
                CartManager.showNotification(data.message || 'Error adding product to cart', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            CartManager.showNotification('Error adding product to cart', 'error');
        });
    }
});
</script>

</body>
</html>