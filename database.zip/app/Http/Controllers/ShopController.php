<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;

class ShopController extends Controller
{
    public function index(Request $request)
    {
        // Start query
        $query = Product::query();
        
        // Search filter
        if ($request->has('search') && !empty($request->search)) {
            $query->where('name', 'like', '%' . $request->search . '%')
                  ->orWhere('description', 'like', '%' . $request->search . '%');
        }
        
        // Price filter
        if ($request->has('min_price') && !empty($request->min_price)) {
            $query->where('price', '>=', $request->min_price);
        }
        if ($request->has('max_price') && !empty($request->max_price)) {
            $query->where('price', '<=', $request->max_price);
        }
        
        // Color filter
        if ($request->has('color') && !empty($request->color)) {
            $query->where('color', $request->color);
        }
        
        // Size filter
        if ($request->has('size') && !empty($request->size)) {
            $query->where('size', $request->size);
        }
        
        // Sorting
        $sortOptions = [
            'newest' => ['created_at', 'desc'],
            'price_asc' => ['price', 'asc'],
            'price_desc' => ['price', 'desc'],
            'name_asc' => ['name', 'asc'],
            'name_desc' => ['name', 'desc'],
        ];
        
        $sort = $request->get('sort', 'newest');
        $sortOption = $sortOptions[$sort] ?? $sortOptions['newest'];
        
        $query->orderBy($sortOption[0], $sortOption[1]);
        
        // Get products with pagination
        $products = $query->paginate(12);
        
        // Get available colors and sizes for filters
        $colors = Product::distinct()->pluck('color')->filter()->values();
        $sizes = Product::distinct()->pluck('size')->filter()->values();
        
        // Get counts for colors and sizes
        $colorCounts = Product::select('color')
            ->selectRaw('COUNT(*) as count')
            ->groupBy('color')
            ->pluck('count', 'color');
            
        $sizeCounts = Product::select('size')
            ->selectRaw('COUNT(*) as count')
            ->groupBy('size')
            ->pluck('count', 'size');
        
        // Get max price for slider
        $maxPrice = Product::max('price') ?? 1000;
        
        return view('shop', compact(
            'products', 
            'colors', 
            'sizes', 
            'colorCounts', 
            'sizeCounts',
            'maxPrice'
        ));
    }
}