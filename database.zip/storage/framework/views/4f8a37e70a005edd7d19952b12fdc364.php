

<?php $__env->startSection('content'); ?>    
    <!--slider area start-->
    <section class="slider_section mb-100">
        <div class="slider_area owl-carousel">
            <div class="single_slider d-flex align-items-center" data-bgimg="assets/img/slider/slider1.jpg">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="slider_content">
                                <h2>Premium Quality Men's Fashion</h2>
                                <h1>Men's Collection</h1>
                                <p>
                                Discover our exclusive range of men's clothing. <span>Style that defines you</span>
                             </p>
                                <a href="<?php echo e(route('shop')); ?>">Shop Now +</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="single_slider d-flex align-items-center" data-bgimg="assets/img/slider/slider2.jpg">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="slider_content">
                                <h2>Up to 40% Off Summer Collection</h2>
                                <h1>Summer Essentials</h1>
                                <p>
                                Stay cool and stylish with our summer range. <span>Limited time offer</span>
                             </p>
                                <a href="<?php echo e(route('shop')); ?>">Shop Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--slider area end-->
    
    <!--banner area start-->
    <div class="banner_area mb-95">
        <div class="container">
            <div class="row no-gutters">
                <div class="col-lg-6 col-md-6">
                    <div class="single_banner">
                        <div class="banner_thumb">
                            <a href="<?php echo e(route('shop', ['category' => 'tshirts'])); ?>"><img src="assets/img/bg/banner4.jpg" alt="Men's Casual Wear"></a>
                            <div class="banner_text1">
                                <div class="banner_text1_inner">
                                    <h3>Casual <br> Collection</h3>
                                    <a href="<?php echo e(route('shop', ['category' => 'tshirts'])); ?>">shop now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="single_banner">
                        <div class="banner_thumb">
                            <a href="<?php echo e(route('shop', ['category' => 'jackets'])); ?>"><img src="assets/img/slider/slider4.jpg" alt="Men's Formal Wear"></a>
                            <div class="banner_text1">
                                <div class="banner_text1_inner">
                                    <h3>Bags <br> Collection</h3>
                                    <a href="<?php echo e(route('shop', ['category' => 'jackets'])); ?>">shop now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--banner area end-->
    
    <!--categories product area start-->
    <div class="categories_product_area mb-92">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title">
                       <h2>Shop By Category</h2>
                    </div>
                </div>
            </div> 
            <div class="row">
               <div class="product_carousel product_column4 owl-carousel">
                   <div class="col-lg-3">
                        <article class="single_categories">
                            <figure>
                                <div class="categories_thumb">
                                    <a href="<?php echo e(route('shop', ['category' => 'tshirts'])); ?>"><img src="assets/img/s-product/tshirt.jpg" alt="T-Shirts"></a>
                                </div>
                                <figcaption class="categories_content">
                                    <h4 class="product_name"><a href="<?php echo e(route('shop', ['category' => 'tshirts'])); ?>">T-Shirts</a></h4>
                                   <div class="product_collection">
                                        <p>Premium cotton t-shirts</p>
                                        <a href="<?php echo e(route('shop', ['category' => 'tshirts'])); ?>">+ Shop Collection</a>
                                    </div>
                                </figcaption>
                            </figure>
                        </article>
                   </div>
                   <div class="col-lg-3">
                        <article class="single_categories">
                            <figure>
                                <div class="categories_thumb">
                                    <a href="<?php echo e(route('shop', ['category' => 'shirts'])); ?>"><img src="assets/img/product/product4.jpg" alt="Shirts"></a>
                                </div>
                                <figcaption class="categories_content">
                                    <h4 class="product_name"><a href="<?php echo e(route('shop', ['category' => 'shirts'])); ?>">Shirts</a></h4>
                                   <div class="product_collection">
                                        <p>Formal & casual shirts</p>
                                        <a href="<?php echo e(route('shop', ['category' => 'shirts'])); ?>">+ Shop Collection</a>
                                    </div>
                                </figcaption>
                            </figure>
                        </article>
                   </div>
                   <div class="col-lg-3">
                        <article class="single_categories">
                            <figure>
                                <div class="categories_thumb">
                                    <a href="<?php echo e(route('shop', ['category' => 'polo-shirts'])); ?>"><img src="assets/img/product/product14.jpg" alt="Polo Shirts"></a>
                                </div>
                                <figcaption class="categories_content">
                                    <h4 class="product_name"><a href="<?php echo e(route('shop', ['category' => 'polo-shirts'])); ?>">Polo Shirts</a></h4>
                                   <div class="product_collection">
                                        <p>Classic polo collection</p>
                                        <a href="<?php echo e(route('shop', ['category' => 'polo-shirts'])); ?>">+ Shop Collection</a>
                                    </div>
                                </figcaption>
                            </figure>
                        </article>
                   </div>
                   <div class="col-lg-3">
                        <article class="single_categories">
                            <figure>
                                <div class="categories_thumb">
                                    <a href="<?php echo e(route('shop', ['category' => 'jeans'])); ?>"><img src="assets/img/bg/banner1.jpg" alt="Jeans"></a>
                                </div>
                                <figcaption class="categories_content">
                                    <h4 class="product_name"><a href="<?php echo e(route('shop', ['category' => 'jeans'])); ?>">Jeans</a></h4>
                                   <div class="product_collection">
                                        <p>Denim in all styles</p>
                                        <a href="<?php echo e(route('shop', ['category' => 'jeans'])); ?>">+ Shop Collection</a>
                                    </div>
                                </figcaption>
                            </figure>
                        </article>
                   </div>
                   <div class="col-lg-3">
                        <article class="single_categories">
                            <figure>
                                <div class="categories_thumb">
                                    <a href="<?php echo e(route('shop', ['category' => 'jackets'])); ?>"><img src="assets/img/s-product/jackets.jpg" alt="Jackets"></a>
                                </div>
                                <figcaption class="categories_content">
                                    <h4 class="product_name"><a href="<?php echo e(route('shop', ['category' => 'jackets'])); ?>">Jackets</a></h4>
                                   <div class="product_collection">
                                        <p>Outerwear for all seasons</p>
                                        <a href="<?php echo e(route('shop', ['category' => 'jackets'])); ?>">+ Shop Collection</a>
                                    </div>
                                </figcaption>
                            </figure>
                        </article>
                   </div>
                   <div class="col-lg-3">
                        <article class="single_categories">
                            <figure>
                                <div class="categories_thumb">
                                    <a href="<?php echo e(route('shop', ['category' => 'footwear'])); ?>"><img src="assets/img/s-product/footwear.jpg" alt="Footwear"></a>
                                </div>
                                <figcaption class="categories_content">
                                    <h4 class="product_name"><a href="<?php echo e(route('shop', ['category' => 'footwear'])); ?>">Footwear</a></h4>
                                   <div class="product_collection">
                                        <p>Shoes & sneakers</p>
                                        <a href="<?php echo e(route('shop', ['category' => 'footwear'])); ?>">+ Shop Collection</a>
                                    </div>
                                </figcaption>
                            </figure>
                        </article>
                   </div>
               </div>
           </div>   
        </div> 
    </div>
    <!--categories product area end-->
    
    <!--testimonial area start-->
    <div class="testimonial_area mb-95">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title">
                       <h2>What Our Customers Say</h2>
                    </div>
                </div>
            </div> 
            <div class="testimonial_container">
                <div class="row">
                    <div class="col-12">
                        <div class="testimonial_wrapper testimonial_collumn1 owl-carousel">
                            <div class="single_testimonial">
                                <div class="testimonial_thumb">
                                    <img src="assets/img/about/testimonial1.png" alt="Customer">
                                </div>
                                <div class="testimonial_content">
                                   <p>The quality of their clothing is exceptional. I've been shopping here for years and the fit is always perfect. Highly recommend their jeans and shirts!</p>
                                    <h3><a href="#">Michael Johnson</a></h3>
                                    <span>Loyal Customer</span>
                                </div>
                            </div>
                            <div class="single_testimonial">
                                <div class="testimonial_thumb">
                                    <img src="assets/img/about/testimonial2.png" alt="Customer">
                                </div>
                                <div class="testimonial_content">
                                   <p>Fast shipping and great customer service. The jacket I ordered fits perfectly and the material quality exceeded my expectations. Will definitely shop again.</p>
                                    <h3><a href="#">David Wilson</a></h3>
                                    <span>First-time Buyer</span>
                                </div>
                            </div>
                            <div class="single_testimonial">
                                <div class="testimonial_thumb">
                                    <img src="assets/img/about/testimonial3.png" alt="Customer">
                                </div>
                                <div class="testimonial_content">
                                   <p>Their collection has everything a modern man needs. From office wear to casual weekends, I always find what I'm looking for at reasonable prices.</p>
                                    <h3><a href="#">James Anderson</a></h3>
                                    <span>Regular Customer</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--testimonial area end-->
    
    <!--featured products area start-->
    <div class="product_area mb-95">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title">
                       <h2>Featured Products</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="product_carousel product_column5 owl-carousel">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3">
                        <div class="product_items">
                            <article class="single_product">
                                <figure>
                                    <div class="product_thumb">
                                        <a class="primary_img" href="<?php echo e(route('product.show', $product->id)); ?>">
                                            <img src="<?php echo e($product->image ? asset($product->image) : asset('assets/img/product/default.jpg')); ?>" alt="<?php echo e($product->name); ?>">
                                        </a>

                                        <div class="action_links">
                                            <ul>
                                                <li class="quick_button">
                                                    <a href="#"
                                                    class="quick-view-btn"
                                                    data-id="<?php echo e($product->id); ?>"
                                                    data-name="<?php echo e($product->name); ?>"
                                                    data-price="<?php echo e(number_format($product->price, 2)); ?>"
                                                    data-oldprice="<?php echo e($product->old_price ?? ''); ?>"
                                                    data-description="<?php echo e($product->description); ?>"
                                                    data-images='<?php echo json_encode([$product->image ? asset($product->image) : asset('assets/img/product/default.jpg')], 15, 512) ?>'
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#modal_box">
                                                        <span class="pe-7s-search"></span>
                                                    </a>
                                                </li>
                                                <li class="wishlist"><a href="<?php echo e(route('wishlist.add', $product->id)); ?>"><span class="pe-7s-like"></span></a></li>
                                            </ul>
                                        </div>
                                    </div>

                                    <figcaption class="product_content">
                                        <h4 class="product_name"><a href="<?php echo e(route('product.show', $product->id)); ?>"><?php echo e($product->name); ?></a></h4>
                                        <div class="price_box">
                                            <span class="current_price">$<?php echo e(number_format($product->price, 2)); ?></span>
                                            <?php if($product->old_price): ?>
                                                <span class="old_price">$<?php echo e(number_format($product->old_price, 2)); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="add_to_cart">
                                            <a href="javascript:void(0)" class="add-to-cart-btn" data-id="<?php echo e($product->id); ?>">Add to cart</a>
                                        </div>
                                    </figcaption>
                                </figure>
                            </article>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <!--featured products area end-->
    
    <!--banner area start-->
    <div class="banner_area">
        <div class="container-fluid p-0">
            <div class="row no-gutters">
                <div class="col-lg-6 col-md-6">
                    <div class="single_banner">
                        <div class="banner_thumb">
                            <a href="<?php echo e(route('shop', ['category' => 'summer'])); ?>"><img src="assets/img/bg/summer-collection.jpg" alt="Summer Collection"></a>
                            <div class="banner_text2">
                                <h3>Summer <br> Collection</h3>
                                <a href="<?php echo e(route('shop', ['category' => 'summer'])); ?>">shop now</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="single_banner">
                        <div class="banner_thumb">
                            <a href="<?php echo e(route('shop', ['category' => 'winter'])); ?>"><img src="assets/img/bg/winter-collection.jpg" alt="Winter Collection"></a>
                            <div class="banner_text2">
                                <h3>Winter <br> Collection</h3>
                                <a href="<?php echo e(route('shop', ['category' => 'winter'])); ?>">shop now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--banner area end-->
    
    <!--discount banner area start-->
    <div class="discount_banner_area mb-95">
        <div class="container-fluid p-0">
            <div class="banner_thumb">
                <a href="<?php echo e(route('shop')); ?>"><img src="/assets/img/bg/mens-sale.jpg" alt="Men's Sale"></a>
                <div class="banner_text3">
                    <h3>Men's Seasonal Collection</h3>
                    <h2>up TO 40% off</h2>
                    <p>An exclusive selection of premium men's clothing. <span>Limited time offer!</span></p>
                    <a href="<?php echo e(route('shop')); ?>">shop now</a>
                </div>
            </div>
        </div>
    </div>
    <!--discount banner area end-->
    
    <!--new arrivals area start-->
    <div class="product_area mb-95">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title">
                       <h2>New Arrivals</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="product_carousel product_column5 owl-carousel">
                    <?php $__currentLoopData = $newArrivals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3">
                        <div class="product_items">
                            <article class="single_product">
                                <figure>
                                    <div class="product_thumb">
                                        <a class="primary_img" href="<?php echo e(route('product.show', $product->id)); ?>">
                                            <img src="<?php echo e($product->image ? asset($product->image) : asset('assets/img/product/default.jpg')); ?>" alt="<?php echo e($product->name); ?>">
                                        </a>
                                        <div class="label_product">
                                            <span class="label_new">New</span>
                                        </div>
                                        <div class="action_links">
                                            <ul>
                                                <li class="quick_button">
                                                    <a href="#"
                                                    class="quick-view-btn"
                                                    data-id="<?php echo e($product->id); ?>"
                                                    data-name="<?php echo e($product->name); ?>"
                                                    data-price="<?php echo e(number_format($product->price, 2)); ?>"
                                                    data-oldprice="<?php echo e($product->old_price ?? ''); ?>"
                                                    data-description="<?php echo e($product->description); ?>"
                                                    data-images='<?php echo json_encode([$product->image ? asset($product->image) : asset('assets/img/product/default.jpg')], 15, 512) ?>'
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#modal_box">
                                                        <span class="pe-7s-search"></span>
                                                    </a>
                                                </li>
                                                <li class="wishlist"><a href="<?php echo e(route('wishlist.add', $product->id)); ?>"><span class="pe-7s-like"></span></a></li>
                                            </ul>
                                        </div>
                                    </div>

                                    <figcaption class="product_content">
                                        <h4 class="product_name"><a href="<?php echo e(route('product.show', $product->id)); ?>"><?php echo e($product->name); ?></a></h4>
                                        <div class="price_box">
                                            <span class="current_price">$<?php echo e(number_format($product->price, 2)); ?></span>
                                            <?php if($product->old_price): ?>
                                                <span class="old_price">$<?php echo e(number_format($product->old_price, 2)); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="add_to_cart">
                                            <a href="javascript:void(0)" class="add-to-cart-btn" data-id="<?php echo e($product->id); ?>">Add to cart</a>
                                        </div>
                                    </figcaption>
                                </figure>
                            </article>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <!--new arrivals area end-->
    
    <!--shipping area start-->
    <div class="shipping_area">
        <div class="container">
            <div class="shipping_container">
                <div class="row">
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single_shipping">
                            <div class="shipping_icone">
                               <img src="assets/img/about/shipping1.png" alt="Free Delivery">
                            </div>
                            <div class="shipping_content">
                               <h3>Free Delivery</h3>
                                <p>Free shipping on all orders over $100</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single_shipping">
                            <div class="shipping_icone">
                               <img src="assets/img/about/shipping2.png" alt="Support">
                            </div>
                            <div class="shipping_content">
                               <h3>Online Support 24/7</h3>
                                <p>Dedicated customer support</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single_shipping">
                            <div class="shipping_icone">
                               <img src="assets/img/about/shipping3.png" alt="Money Return">
                            </div>
                            <div class="shipping_content">
                               <h3>Money Return</h3>
                                <p>30 days money back guarantee</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single_shipping">
                            <div class="shipping_icone">
                               <img src="assets/img/about/shipping4.png" alt="Member Discount">
                            </div>
                            <div class="shipping_content">
                               <h3>Member Discount</h3>
                                <p>Extra 10% off for members</p>
                            </div>
                        </div>
                    </div>
                </div>  
            </div> 
        </div>
    </div>
    <!--shipping area end-->
    
    <!--brand area start-->
    <div class="brand_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="brand_container owl-carousel">
                        <div class="single_brand">
                            <a href="#"><img src="assets/img/brand/brand1.jpg" alt="Brand"></a>
                        </div>
                        <div class="single_brand">
                            <a href="#"><img src="assets/img/brand/brand2.jpg" alt="Brand"></a>
                        </div>
                        <div class="single_brand">
                            <a href="#"><img src="assets/img/brand/brand3.jpg" alt="Brand"></a>
                        </div>
                        <div class="single_brand">
                            <a href="#"><img src="assets/img/brand/brand4.jpg" alt="Brand"></a>
                        </div>
                        <div class="single_brand">
                            <a href="#"><img src="assets/img/brand/brand5.jpg" alt="Brand"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--brand area end-->
   
    <!-- Modal -->
    <div class="modal fade" id="modal_box" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true"><i class="ion-android-close"></i></span>
                </button>
                <div class="modal_body">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-5 col-md-5 col-sm-12">
                                <div class="modal_tab">  
                                    <div class="tab-content product-details-large" id="modal_image_tabs">
                                        <!-- JS will inject product images here -->
                                    </div>
                                </div>  
                            </div> 
                            <div class="col-lg-7 col-md-7 col-sm-12">
                                <div class="modal_right">
                                    <div class="modal_title mb-10">
                                        <h2 id="modal_product_name"></h2> 
                                    </div>
                                    <div class="modal_price mb-10">
                                        <span class="new_price" id="modal_product_price"></span>    
                                        <span class="old_price" id="modal_product_oldprice"></span>    
                                    </div>
                                    <div class="modal_description mb-15">
                                        <p id="modal_product_description"></p>    
                                    </div> 
                                    <div class="variants_selects">
                                        <div class="variants_size">
                                            <h2>size</h2>
                                            <select class="select_option">
                                                <option selected value="S">S</option>
                                                <option value="M">M</option>
                                                <option value="L">L</option>
                                                <option value="XL">XL</option>
                                                <option value="XXL">XXL</option>
                                            </select>
                                        </div>
                                        <div class="variants_color">
                                            <h2>color</h2>
                                            <select class="select_option">
                                                <option selected value="black">Black</option>
                                                <option value="navy">Navy</option>
                                                <option value="gray">Gray</option>
                                                <option value="white">White</option>
                                                <option value="brown">Brown</option>
                                            </select>
                                        </div>
                                        <div class="modal_add_to_cart">
                                            <form id="modal_add_to_cart_form">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="product_id" id="modal_product_id">
                                                <input min="1" max="100" step="1" value="1" type="number" name="quantity" id="modal_quantity">
                                                <button type="submit">add to cart</button>
                                            </form>
                                        </div>   
                                    </div>
                                    <div class="modal_social">
                                        <h2>Share this product</h2>
                                        <ul>
                                            <li class="facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li class="twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li class="pinterest"><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                        </ul>    
                                    </div>      
                                </div>    
                            </div>    
                        </div>     
                    </div>
                </div>    
            </div>
        </div>
    </div>
    <!-- modal area end-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener("DOMContentLoaded", function() {
    // Quick view modal functionality
    document.querySelectorAll(".quick-view-btn").forEach(btn => {
        btn.addEventListener("click", function() {
            // Fill product info
            document.getElementById("modal_product_id").value = this.dataset.id;
            document.getElementById("modal_product_name").textContent = this.dataset.name;
            document.getElementById("modal_product_price").textContent = "$" + this.dataset.price;
            
            // Handle old price
            const oldPriceEl = document.getElementById("modal_product_oldprice");
            if (this.dataset.oldprice && this.dataset.oldprice !== "0") {
                oldPriceEl.textContent = "$" + this.dataset.oldprice;
                oldPriceEl.style.display = "inline-block";
            } else {
                oldPriceEl.style.display = "none";
            }
            
            document.getElementById("modal_product_description").textContent = this.dataset.description || "No description available";

            // Parse images
            let images = [];
            try {
                images = JSON.parse(this.dataset.images.replace(/&quot;/g, '"'));
            } catch (e) {
                images = [this.dataset.images || 'assets/img/product/default.jpg'];
            }

            // Rebuild main image tabs
            const tabs = document.getElementById("modal_image_tabs");
            tabs.innerHTML = "";
            images.forEach((img, i) => {
                tabs.innerHTML += `
                    <div class="tab-pane fade ${i === 0 ? "show active" : ""}" id="tab${i+1}" role="tabpanel">
                        <div class="modal_tab_img">
                            <a href="#"><img src="${img}" alt="${this.dataset.name}"></a>    
                        </div>
                    </div>
                `;
            });
        });
    });

    // Modal add to cart form submission
    document.getElementById("modal_add_to_cart_form")?.addEventListener("submit", function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        addToCart(formData);
    });

    // Add to cart function
    function addToCart(formData) {
        fetch('<?php echo e(route("cart.add")); ?>', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            }
        })
        .then(response => {
            if (response.status === 401) {
                return response.json().then(data => {
                    if (data.redirect) {
                        window.location.href = data.redirect;
                    } else {
                        window.location.href = '<?php echo e(route("login")); ?>';
                    }
                    return { success: false };
                });
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                if (typeof CartManager !== 'undefined') {
                    CartManager.updateMiniCart(data);
                    CartManager.showNotification('Product added to cart!', 'success');
                } else {
                    showNotification('Product added to cart!', 'success');
                }
                
                // Close modal if it's open
                const modal = document.getElementById('modal_box');
                if (modal) {
                    const bootstrapModal = bootstrap.Modal.getInstance(modal);
                    if (bootstrapModal) {
                        bootstrapModal.hide();
                    }
                }
                
                window.dispatchEvent(new CustomEvent('cart:updated', { detail: data }));
            } else if (data.redirect) {
                window.location.href = data.redirect;
            } else {
                if (typeof CartManager !== 'undefined') {
                    CartManager.showNotification(data.message || 'Error adding product to cart', 'error');
                } else {
                    showNotification(data.message || 'Error adding product to cart', 'error');
                }
            }
        })
        .catch(error => {
            console.error('Error:', error);
            if (typeof CartManager !== 'undefined') {
                CartManager.showNotification('Error adding product to cart', 'error');
            } else {
                showNotification('Error adding product to cart', 'error');
            }
        });
    }

    // Show notification function
    function showNotification(message, type) {
        document.querySelectorAll('.cart-notification').forEach(el => el.remove());
        
        const notification = document.createElement('div');
        notification.className = `cart-notification alert alert-${type === 'success' ? 'success' : 'danger'} fixed-top mx-auto mt-3`;
        notification.style.cssText = 'max-width: 300px; z-index: 9999; left: 50%; transform: translateX(-50%); text-align: center; padding: 10px;';
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Cipher\Documents\Shop\htmldemo.net\braga\fashion-store\resources\views/home.blade.php ENDPATH**/ ?>