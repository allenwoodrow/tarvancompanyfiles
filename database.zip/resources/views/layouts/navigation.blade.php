<!--offcanvas menu area start-->
<div class="off_canvars_overlay"></div>
<div class="offcanvas_menu">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="canvas_open">
                    <a href="javascript:void(0)"><i class="ion-navicon-round"></i></a>
                </div>
                <div class="offcanvas_menu_wrapper">
                    <div class="canvas_close">
                        <a href="javascript:void(0)"><i class="ion-android-close"></i></a>
                    </div>

                    <div id="menu" class="text-left">
                        <ul class="offcanvas_main_menu">
                            <li class="{{ request()->routeIs('home') ? 'active' : '' }}"><a href="{{ route('home') }}">Home</a></li>
                            <li><a href="{{ route('shop') }}">Shop</a></li>
                            @auth
                                <li><a href="{{ route('profile.edit') }}">My Account</a></li>
                                <li><a href="{{ route('cart.index') }}">Cart</a></li>
                                <li>
                                    <form method="POST" action="{{ route('logout') }}">
                                        @csrf
                                        <button type="submit" class="bg-transparent border-0">Logout</button>
                                    </form>
                                </li>
                            @endauth
                            @guest
                                <li><a href="{{ route('login') }}">Login</a></li>
                                <li><a href="{{ route('register') }}">Register</a></li>
                            @endguest
                            <li><a href="{{ url('/about') }}">About Us</a></li>
                            <li><a href="{{ url('/contact') }}">Contact Us</a></li>
                        </ul>
                    </div>

                    <div class="offcanvas_footer">
                        <span><a href="mailto:info@sodlifestyle.com"><i class="fa fa-envelope-o"></i> info@sodlifestyle.com</a></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--offcanvas menu area end-->

<header>
    <div class="main_header sticky-header">
        <div class="container">
            <div class="row align-items-center">
                <!-- Logo -->
                <div class="col-lg-2 col-md-4 col-5 offset-3 offset-md-4 offset-lg-0">
                    <div class="logo">
                        <a href="{{ route('home') }}">
                            <img src="{{ asset('assets/img/logo/logo.png') }}" alt="SOD Life+Style">
                        </a>
                    </div>
                </div>

                <!-- Menu -->
                <div class="col-lg-8">
                    <div class="main_menu menu_position">
                        <nav>
                            <ul>
                                <li><a class="{{ request()->routeIs('home') ? 'active' : '' }}" href="{{ route('home') }}">Home</a></li>
                                <li><a href="{{ route('shop') }}">Shop</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>

                <!-- Cart & User -->
                <div class="col-lg-2 col-md-4 col-sm-4 col-4">
                    <div class="header_account_area">
                        <!-- Search -->
                        <div class="header_account_list search_list">
                            <a href="javascript:void(0)"><span class="pe-7s-search"></span></a>
                            <div class="dropdown_search">
                                <form action="{{ route('shop') }}" method="GET">
                                    <input placeholder="Search entire store here ..." type="text" name="q">
                                    <button type="submit"><span class="pe-7s-search"></span></button>
                                </form>
                            </div>
                        </div>

                        <!-- Cart -->
                        <div class="header_account_list mini_cart_wrapper">
                            <a href="javascript:void(0)">
                                <span class="pe-7s-shopbag"></span>
                                <span class="item_count">0</span>
                            </a>
                        </div>

                        <!-- User Dropdown -->
                        <div class="language_currency header_account_list">
                            <a href="#"><span class="pe-7s-user"></span></a>
                            <ul class="dropdown_currency">
                                @auth
                                    <li>Hello, <strong>{{ Auth::user()->name }}</strong></li>
                                    <li><a href="{{ route('profile.edit') }}">My Account</a></li>
                                    <li><a href="{{ route('cart.index') }}">Cart</a></li>
                                    <li>
                                        <form method="POST" action="{{ route('logout') }}">
                                            @csrf
                                            <button type="submit" class="w-100 text-start bg-transparent border-0">Logout</button>
                                        </form>
                                    </li>
                                @endauth
                                @guest
                                    <li><a href="{{ route('login') }}">Login</a></li>
                                    <li><a href="{{ route('register') }}">Register</a></li>
                                @endguest
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Mini Cart -->
    <div class="mini_cart">
        <div class="cart_gallery">
            <div class="cart_close">
                <div class="cart_text"><h3>Cart</h3></div>
                <div class="mini_cart_close"><a href="javascript:void(0)"><i class="ion-android-close"></i></a></div>
            </div>
            
            <!-- Cart items will be loaded dynamically via JavaScript -->
            <p class="text-center">Your cart is empty</p>
        </div>

        <div class="mini_cart_table">
            <div class="cart_table_border">
                <div class="cart_total">
                    <span>Sub total:</span>
                    <span class="price subtotal-price">$0.00</span>
                </div>
                <div class="cart_total mt-10">
                    <span>Total:</span>
                    <span class="price total-price">$0.00</span>
                </div>
            </div>
        </div>

        <div class="mini_cart_footer">
            <div class="cart_button">
                <a href="{{ route('cart.index') }}"><i class="fa fa-shopping-cart"></i> View cart</a>
            </div>
        </div>
    </div>
</header>