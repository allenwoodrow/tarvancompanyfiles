

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="mb-4">Payments</h2>
    <a href="<?php echo e(route('admin.payments.create')); ?>" class="btn btn-primary mb-3">➕ Record Payment</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-striped align-middle">
        <thead>
            <tr>
                <th>#</th>
                <th>Order</th>
                <th>User</th>
                <th>Amount ($)</th>
                <th>Method</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($payment->id); ?></td>
                <td>#<?php echo e($payment->order->id); ?></td>
                <td><?php echo e($payment->order->user->name); ?></td>
                <td>$<?php echo e(number_format($payment->amount, 2)); ?></td>
                <td><?php echo e(ucfirst($payment->method)); ?></td>
                <td><?php echo e(ucfirst($payment->status)); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.payments.edit', $payment)); ?>" class="btn btn-sm btn-warning">✏ Edit</a>
                    <form action="<?php echo e(route('admin.payments.destroy', $payment)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger" onclick="return confirm('Delete payment?')">🗑 Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="7" class="text-center">No payments found</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Cipher\Documents\Shop\htmldemo.net\braga\fashion-store\resources\views/admin/payments/index.blade.php ENDPATH**/ ?>